/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz2;

/**
 *
 * @author macbookpro
 */
public class ArbolB {
    Nodo raiz;
    
    public void setRaiz(Nodo n){
        this.raiz = n;
    }
    
    public boolean vacio(Nodo n){
        return n==null;
    }
        

    public void insertarIzq(int padre , int valorIzq){
        Nodo n = find(raiz , padre);
        Nodo hijoIzq = new Nodo(valorIzq);
        n.Set_hIzq(hijoIzq);
    }

    
    public void insertarDer(int padre , int valorDer){
        Nodo n = find(raiz, padre);
        Nodo hijoDer = new Nodo(valorDer);
        n.Set_hDer(hijoDer);
    }

    
    public void insertarRaiz(int data){
        raiz = new Nodo(data);
    }

    
    
    
    public Nodo getRaiz(){
        return raiz;
    }


    public Nodo find(Nodo n, int clave){
        Nodo result = null;
        if(n == null){
            return null;
        }
        if(n.get_info() == clave){
            return n;
        }
        if(n.hIzq() != null){
            result = find(n.hIzq(), clave);
        }
        if(result == null){
            result = find(n.hDer(), clave);
        }
        
        return result;
    }


	public int get_Tamaño(Nodo root) {
		if (root == null)
			return 0;
		return Math.max(get_Tamaño(root.hIzq()), get_Tamaño(root.hDer())) + 1;
	}

       
        
public void insertar (ArbolB arbol, int [] nodos){
    Nodo raizSecuencia = new Nodo(nodos[0]);
    arbol.raiz = raizSecuencia;
    int veces = (nodos.length-1)/2;
    int primero = 1;
    int segundo = 2;
    int tercero = 3;
    int cuarto = 4;
    int quinto = 1;
    int sexto = 2;
    
    if(nodos.length>1){
        if(veces%2==0){
            for (int i = 0; i<(veces/2); i++) {
                arbol.insertarIzq(nodos[primero], nodos[segundo]);
                arbol.insertarDer(nodos[tercero], nodos[cuarto]);
                primero = primero + 4;
                segundo = segundo + 4;
                tercero = tercero + 4;
                cuarto = cuarto + 4;
            }   
                
        }else{
            if(veces>1){
            for (int i = 0; i<((veces-1)/2); i++) {
                arbol.insertarIzq(nodos[primero], nodos[segundo]);
                arbol.insertarDer(nodos[tercero], nodos[cuarto]);
                primero = primero + 4;
                segundo = segundo + 4;
                tercero = tercero + 4;
                cuarto = cuarto + 4;
                quinto = quinto + 4;
                sexto = sexto + 4;
            }
                arbol.insertarIzq(nodos[quinto], nodos[sexto]);
            }
            
            arbol.insertarIzq(nodos[1], nodos[2]);
        }
    }
}

public boolean Secuencia(int[] nodos){
    boolean response = true;
    
    int veces = (nodos.length-1)/2;
    int primero = 1;
    int segundo = 2;
    int tercero = 3;
    int cuarto = 4;
    if(nodos.length%2==0){
        response = false;
    }
    if(nodos.length>1){
        if(veces%2==0){
            for (int i = 0; i<(veces/2); i++) {
                if(nodos[primero]!=nodos[tercero]){
                    response = false;
                }   
                primero = primero + 4;
                segundo = segundo + 4;
                tercero = tercero + 4;
                cuarto = cuarto + 4;
            }   
                
        }else{
            if(veces>1){
            for (int i = 0; i<((veces-1)/2); i++) {
                if(nodos[primero]!=nodos[tercero]){
                    response = false;
                }
                primero = primero + 4;
                segundo = segundo + 4;
                tercero = tercero + 4;
                cuarto = cuarto + 4;
            }
          }

        }
    }
    
    return response;
}


}
