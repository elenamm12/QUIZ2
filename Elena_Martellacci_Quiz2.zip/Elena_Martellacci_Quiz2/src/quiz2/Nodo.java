/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz2;

/**
 *
 * @author macbookpro
 */
public class Nodo {
    private int info;
    private Nodo izquierdo;
    private Nodo derecho;
    public int max;
    public int min;
	
    public Nodo(int data) {
	this.info = data;
	this.izquierdo = null;
	this.derecho = null;
    }
    
        
    public int get_info(){
        return this.info;
    }
    
    public void Set_info(int data){
        this.info=data;
    }
    
    public void set_max(int info){
        this.max = info;
    }
    
    public void set_min(int info){
        this.min = info;
    }
    
    public Nodo hIzq(){
        return this.izquierdo;
    }
         
    public Nodo hDer(){
        return this.derecho;
    }
   
    public void Set_hIzq(Nodo n){
        this.izquierdo=n;
    }
         
    public void Set_hDer(Nodo n){
        this.derecho=n;
    }

    public void MaxAndMin(Nodo raiz){
        int padre = raiz.info;
        
        if(raiz.hDer()!=null || raiz.hIzq()!=null){
            if (raiz.hIzq()!=null) {
                raiz.hIzq().set_max(padre);
                raiz.MaxAndMin(raiz.hIzq());   
            }
            
            if(raiz.hDer()!=null){
                raiz.hDer().set_min(padre);
                raiz.MaxAndMin(raiz.hDer());
            }
            
        }
        
    }
    
    
}
