/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz2;

/**
 *
 * @author macbookpro
 */
public class Solucion {
    
    public boolean BuscarIzquierdo(Nodo n, int comparacion){
        boolean respuesta = true;
        if(n.get_info()>comparacion){
            respuesta = false;
        }
        if(n.hIzq()!=null || n.hDer()!=null){

            if(n.hIzq()!=null){
                if(n.hIzq().get_info()>comparacion){
                    
                    respuesta = false;
                    
                }else{
                    
                respuesta = BuscarIzquierdo(n.hIzq(),comparacion);
                
                }
            }

            if(n.hDer()!=null){
                if(n.hDer().get_info()>comparacion){
                    
                    respuesta = false;
                    
                }else{
                    
                    respuesta = BuscarIzquierdo(n.hDer(),comparacion);
                    
                }
            }
        
        }
          
        return respuesta;
    }
    
    public boolean BuscarDerecho(Nodo n, int comparacion){
        boolean respuesta = true;
        if(n.get_info()<comparacion){
            respuesta = false;
        }
        if(n.hIzq()!=null || n.hDer()!=null){

            if(n.hIzq()!=null){
                if(n.hIzq().get_info()<comparacion){
                    
                    respuesta = false;
                    
                }else{
                    
                respuesta = BuscarIzquierdo(n.hIzq(),comparacion);
                
                }
            }

            if(n.hDer()!=null){
                if(n.hDer().get_info()<comparacion){
                    
                    respuesta = false;
                    
                }else{
                    
                    respuesta = BuscarIzquierdo(n.hDer(),comparacion);
                    
                }
            }
        
        }
          
        return respuesta;
        
        
    }
    
    
    public boolean Es_ABB(Nodo primero){
        int comparacion = primero.get_info();
        boolean respuesta = true;
        boolean igualIzq = true;
        boolean igualDer = true;
        boolean forma = Pre_ABB(primero);
        
        if(primero.hIzq()!=null){
            igualIzq = BuscarIzquierdo(primero.hIzq(),primero.get_info());
        }
        
        if(primero.hDer()!=null){
        igualDer = BuscarDerecho(primero.hDer(),primero.get_info());
        }
        
        if(!forma || !igualIzq || !igualDer){
            respuesta = false;
        }
        
        return respuesta;
    }
    
    
    public boolean Pre_ABB(Nodo raiz){
        boolean resp = true;
        
        if(raiz.hIzq()!=null || raiz.hDer()!=null){
        
            if(raiz.hIzq()!=null){
                if(raiz.hIzq().get_info()>raiz.get_info()){
                    resp = false;
                    
                }
                Pre_ABB(raiz.hIzq());
            }
        
            if(raiz.hDer()!=null){
                if(raiz.hDer().get_info()<raiz.get_info()){
                    resp = false;
                }
                Pre_ABB(raiz.hDer());
            }
        
        }
        
        return resp;
    }
    
    
    
}
